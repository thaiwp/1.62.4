#!/bin/sh
if [ -x /usr/local/directadmin/custombuild/custom/unit/check_unit.sh ] && echo "$0" | grep -m1 -q '/configure/'; then
    /usr/local/directadmin/custombuild/custom/unit/check_unit.sh
    exit $?
fi

TASK_QUEUE=/usr/local/directadmin/data/task.queue.cb

run_dataskq() {
	DATASKQ_OPT=$1
	if [ -s ${DACONF_FILE} ]; then
		/usr/local/directadmin/dataskq ${DATASKQ_OPT} --custombuild
	fi
}

if [ -e /var/run/unit/control.sock ]; then
	curl -s --unix-socket /var/run/unit/control.sock http://localhost/config/listeners | head -n1 | grep -m1 -q '{}' && echo "action=rewrite&value=nginx_unit" >> ${TASK_QUEUE}
	run_dataskq
fi
